package com.aula03.rentx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentxApplication {

	public static void main(String[] args) {
		SpringApplication.run(RentxApplication.class, args);
	}

}
